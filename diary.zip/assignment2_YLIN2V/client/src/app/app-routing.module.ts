import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainPageComponent } from './main-page/main-page.component';
import { DiaryFormComponent } from './diary-form/diary-form.component';
import { DiaryDetailComponent } from './diary-detail/diary-detail.component';
import { DiaryListComponent } from './diary-list/diary-list.component';
import { AboutPageComponent } from './about-page/about-page.component';
import { DiaryEditComponent } from './diary-edit/diary-edit.component';

const routes: Routes = [
  {
    path: "",
    component: MainPageComponent
  },
  {
    path: "diaries",
    component: DiaryListComponent,
  },
  {
    path: "diaries/new",
    component: DiaryEditComponent,
  },
  {
    path: "diaries/:id",
    component: DiaryDetailComponent,
  },
  {
    // about
    path: "about",
    component:AboutPageComponent,
  },
  {
    path: "diaries/:id/edit",
    component: DiaryEditComponent,
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
