import { Injectable } from '@angular/core';
import { Diary } from './diary';
import { HttpClient } from '@angular/common/http';
import { lastValueFrom } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DiaryService {

  diaries : Diary[] = [{
    id: 1,
    title: 'Diary 1',
    entry: 'This is the first diary',
    date: '2021-01-01',
  },
  {
    id: 2,
    title: 'Diary 2',
    entry: 'This is the second diary',
    date: '2021-01-02',
  },
  {
    id: 3,
    title: 'Diary 3',
    entry: 'This is the third diary',
    date: '2021-01-03',
  },];

  private diaryUrl = 'http://localhost:8000/api/diaries';

  constructor(private http : HttpClient) { }

  getDiaries() {
    return lastValueFrom(this.http.get<Diary[]>(this.diaryUrl))
  };

  getDiary(id: number) {
    // return this.diaries.find(diary => diary.id === id);
    return lastValueFrom(this.http.get<Diary>(`${this.diaryUrl}/${id}`));
  };

  addDiary(diary: Diary) {
    // diary.id = this.diaries[this.diaries.length-1].id + 1;
    // this.diaries.push(diary);
    return lastValueFrom(this.http.post<Diary>(this.diaryUrl, diary));
  };

  updateDiary(id : number, diary: Diary) {
    // diary.id = id;
    // this.diaries = this.diaries.map(d => d.id === id ? diary : d);
    return lastValueFrom(this.http.patch<Diary>(`${this.diaryUrl}/${id}`, diary));

  };

  deleteDiary(id : number) {
    // this.diaries = this.diaries.filter(d => d.id !== id);
    return lastValueFrom(this.http.delete<Diary>(`${this.diaryUrl}/${id}`));
  };

  async getDiariesFive() {
    try {
      const diaries = await lastValueFrom(this.http.get<Diary[]>(this.diaryUrl));

      if (diaries.length === 0) {
        return { earliestCount: 0, latestCount: 0 };
      }

      let earliestDate = diaries[0].date;
      let latestDate = diaries[0].date;
      let earliestCount = 0;
      let latestCount = 0;

      for (let diary of diaries) {
        if (diary.date < earliestDate) {
          earliestDate = diary.date;
          earliestCount = 1;
        } else if (diary.date === earliestDate) {
          earliestCount++;
        }

        if (diary.date > latestDate) {
          latestDate = diary.date;
          latestCount = 1;
        } else if (diary.date === latestDate) {
          latestCount++;
        }
      }
      earliestCount += latestCount;
      return { earliestCount, earliestDate, latestDate};
    } catch (error) {
      console.error("Error fetching diaries", error);
      return { earliestCount: 0, latestCount: 0 };
    }
  }
}
