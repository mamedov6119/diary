import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { MainPageComponent } from './main-page/main-page.component';
import { DiaryListComponent } from './diary-list/diary-list.component';
import { DiaryDetailComponent } from './diary-detail/diary-detail.component';
import { DiaryFormComponent } from './diary-form/diary-form.component';
import { AboutPageComponent } from './about-page/about-page.component';
import { ReactiveFormsModule } from '@angular/forms';
import { DiaryEditComponent } from './diary-edit/diary-edit.component';
import {HttpClientModule} from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,
    NavBarComponent,
    MainPageComponent,
    DiaryListComponent,
    DiaryDetailComponent,
    DiaryFormComponent,
    AboutPageComponent,
    DiaryEditComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    ReactiveFormsModule,
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
