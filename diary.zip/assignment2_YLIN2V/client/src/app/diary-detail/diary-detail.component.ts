import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DiaryService } from '../diary.service';
import { Diary } from '../diary';

@Component({
  selector: 'app-diary-detail',
  templateUrl: './diary-detail.component.html',
  styleUrls: ['./diary-detail.component.css']
})
export class DiaryDetailComponent implements OnInit {

  diary : Diary = new Diary();

  constructor(private route : ActivatedRoute, private diaryService : DiaryService, private router : Router) { }

  async ngOnInit() {
    const paramId = this.route.snapshot.paramMap.get('id');
    if (paramId != null) {
      const id = parseInt(paramId);
      const diary = await this.diaryService.getDiary(id);
      if (diary) {
        this.diary = diary;
      }
    }
  }

  async handleDelete() {
    await this.diaryService.deleteDiary(this.diary.id).then(() => {
      this.router.navigate(["/diaries"]);
    });
  };
}
