import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { Diary } from '../diary';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-diary-form',
  templateUrl: './diary-form.component.html',
  styleUrls: ['./diary-form.component.css']
})
export class DiaryFormComponent implements OnChanges{
  @Input() diary = new Diary();
  @Output() save = new EventEmitter<Diary>();
  constructor(private fb: FormBuilder) { 

  }

  ngOnChanges(): void {
    this.diaryForm.patchValue({
      title: this.diary.title,
      entry: this.diary.entry,
      date: this.diary.date,
    });
  }


  diaryForm = this.fb.group({
    title: ['', [Validators.required]],
    entry: ['', [Validators.required]],
    date: ['', [Validators.required, Validators.pattern('[0-9]{4}-[0-9]{2}-[0-9]{2}')]],
  });

  get title() { return this.diaryForm.get('title'); }

  get entry() { return this.diaryForm.get('entry'); }
  
  get date() { return this.diaryForm.get('date'); }

  onSubmit() {
    const diary = new Diary();
    this.save.emit(Object.assign(diary, this.diaryForm.value));
    // console.log(this.diaryForm.value);
  }
}
