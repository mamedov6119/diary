export class Diary {
    id = 0;
    title = "";
    entry = "";
    date = "";
}
