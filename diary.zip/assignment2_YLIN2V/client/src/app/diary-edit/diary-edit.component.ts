import { Component, OnInit } from '@angular/core';
import { Diary } from '../diary';
import { DiaryService } from '../diary.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-diary-edit',
  templateUrl: './diary-edit.component.html',
  styleUrls: ['./diary-edit.component.css']
})
export class DiaryEditComponent implements OnInit {

  diary : Diary = new Diary();

  constructor(private diaryService : DiaryService, private router : Router, private route : ActivatedRoute, private location : Location) { }

  async handleSave(diary : Diary) {
    if (this.diary.id === 0) {
      await this.diaryService.addDiary(diary);
      this.router.navigate(["/diaries"]);
    } else {
      await this.diaryService.updateDiary(this.diary.id, diary);
      this.location.back();
    }
  };

    async ngOnInit(){
    const paramId = this.route.snapshot.paramMap.get('id');
    if (paramId != null) {
      const id = parseInt(paramId);
      const diary = await this.diaryService.getDiary(id);
      this.diary = diary != null ? diary : new Diary();
    }
  };
}
