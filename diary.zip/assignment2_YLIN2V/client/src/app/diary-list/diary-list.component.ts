import { Component, OnInit } from '@angular/core';
import { Diary } from '../diary';
import { DiaryService } from '../diary.service';

@Component({
  selector: 'app-diary-list',
  templateUrl: './diary-list.component.html',
  styleUrls: ['./diary-list.component.css'],
})
export class DiaryListComponent implements OnInit{
  diaries : Diary[] = [];
  selectedDiary: Diary | null = null;


  constructor(private diaryService: DiaryService) {}

  async ngOnInit() {
    this.diaries = await this.diaryService.getDiaries();
  }

  handleSave(diary: Diary) {
    if (this.selectedDiary != null) {
      Object.assign(this.selectedDiary, diary);
      this.selectedDiary = null;
    }
    
  };


}
