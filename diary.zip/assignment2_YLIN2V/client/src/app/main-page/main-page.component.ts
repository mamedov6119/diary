import { Component, OnInit } from '@angular/core';
import { DiaryService } from '../diary.service';
import { Diary } from '../diary';

@Component({
  selector: 'app-main-page',
  templateUrl: './main-page.component.html',
  styleUrls: ['./main-page.component.css']
})
export class MainPageComponent implements OnInit{
  
  sum = 0;
  earliestDate = "";
  latestDate = "";
  title = 'My diary app';
  
  
  constructor(private diaryService : DiaryService) { }

  async ngOnInit() {
    // use getDiariesFive() instead of getDiaries()
    const diaries: any = await this.diaryService.getDiariesFive();
    this.sum = diaries && diaries.earliestCount ? diaries.earliestCount : 0;
    this.earliestDate = diaries && diaries.earliestDate ? diaries.earliestDate : "";
    this.latestDate = diaries && diaries.latestDate ? diaries.latestDate : "";

  }
}
